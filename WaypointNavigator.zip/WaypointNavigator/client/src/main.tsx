import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Регистрируем Service Worker для офлайн-работы
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then((registration) => {
        console.log('Service Worker зарегистрирован для офлайн-работы');
      })
      .catch((error) => {
        console.log('Ошибка регистрации Service Worker:', error);
      });
  });
}

console.log('Приложение запущено в браузере');

createRoot(document.getElementById("root")!).render(<App />);
