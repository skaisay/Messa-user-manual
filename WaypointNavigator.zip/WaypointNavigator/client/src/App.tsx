import { useState } from 'react';
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Home } from './pages/Home';
import { Shorts } from './pages/Shorts';
import { Subscriptions } from './pages/Subscriptions';
import { Library } from './pages/Library';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { VideoPlayer } from './components/VideoPlayer';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const handleVideoClick = (video: any) => {
    setCurrentVideo(video);
    setIsPlayerOpen(true);
  };

  const handleClosePlayer = () => {
    setIsPlayerOpen(false);
  };

  const handleSearch = (query: string) => {
    console.log('Поиск:', query);
    setSearchQuery(query);
  };

  const handleCategoryChange = (category: string) => {
    console.log('Категория:', category);
    setCategoryFilter(category);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="h-screen flex flex-col bg-black text-white">
          {!isPlayerOpen && (
            <>
              <Header onSearch={handleSearch} onCategoryChange={handleCategoryChange} />
              <main className="flex-1 overflow-y-auto pb-18">
                {activeTab === 'home' && <Home onVideoClick={handleVideoClick} searchQuery={searchQuery} categoryFilter={categoryFilter} />}
                {activeTab === 'shorts' && <Shorts />}
                {activeTab === 'subscriptions' && <Subscriptions onVideoClick={handleVideoClick} searchQuery={searchQuery} />}
                {activeTab === 'library' && <Library onVideoClick={handleVideoClick} searchQuery={searchQuery} />}
              </main>
              <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
            </>
          )}
          
          {isPlayerOpen && currentVideo && (
            <VideoPlayer video={currentVideo} onClose={handleClosePlayer} />
          )}
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;