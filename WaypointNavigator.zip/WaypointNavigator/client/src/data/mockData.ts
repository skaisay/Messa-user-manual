export const mockVideos = [
  {
    id: 'dQw4w9WgXcQ',
    videoId: 'dQw4w9WgXcQ',
    title: 'Rick Astley - Never Gonna Give You Up (Official Video)',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    channelName: 'Rick Astley',
    channel: 'Rick Astley',
    channelImage: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    views: '1.4B просмотров',
    uploadTime: '14 лет назад',
    duration: '3:33',
    likes: '13M',
    subscribers: '3.2M',
    description: 'The official video for "Never Gonna Give You Up" by Rick Astley',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    createdAt: new Date()
  },
  {
    id: '9bZkp7q19f0',
    videoId: '9bZkp7q19f0',
    title: 'PSY - GANGNAM STYLE(강남스타일) M/V',
    thumbnail: 'https://img.youtube.com/vi/9bZkp7q19f0/maxresdefault.jpg',
    channelName: 'officialpsy',
    channel: 'officialpsy',
    channelImage: 'https://img.youtube.com/vi/9bZkp7q19f0/maxresdefault.jpg',
    views: '4.8B просмотров',
    uploadTime: '12 лет назад',
    duration: '4:13',
    likes: '22M',
    subscribers: '15.1M',
    description: 'PSY - GANGNAM STYLE(강남스타일) M/V @ https://youtu.be/9bZkp7q19f0',
    videoUrl: 'https://www.youtube.com/watch?v=9bZkp7q19f0',
    createdAt: new Date()
  },
  {
    id: 'kJQP7kiw5Fk',
    videoId: 'kJQP7kiw5Fk',
    title: 'Luis Fonsi - Despacito ft. Daddy Yankee',
    thumbnail: 'https://img.youtube.com/vi/kJQP7kiw5Fk/maxresdefault.jpg',
    channelName: 'Luis Fonsi',
    channel: 'Luis Fonsi',
    channelImage: 'https://img.youtube.com/vi/kJQP7kiw5Fk/maxresdefault.jpg',
    views: '8.3B просмотров',
    uploadTime: '7 лет назад',
    duration: '4:42',
    likes: '50M',
    subscribers: '62.4M',
    description: 'Despacito" disponible ya en todas las plataformas digitales',
    videoUrl: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
    createdAt: new Date()
  },
  {
    id: 'YQHsXMglC9A',
    videoId: 'YQHsXMglC9A',
    title: 'Adele - Hello (Official Music Video)',
    thumbnail: 'https://img.youtube.com/vi/YQHsXMglC9A/maxresdefault.jpg',
    channelName: 'Adele',
    channel: 'Adele',
    channelImage: 'https://img.youtube.com/vi/YQHsXMglC9A/maxresdefault.jpg',
    views: '3.6B просмотров',
    uploadTime: '8 лет назад',
    duration: '6:07',
    likes: '17M',
    subscribers: '29.4M',
    description: 'Listen to "Easy On Me" here: http://Adele.lnk.to/EasyOnMe',
    videoUrl: 'https://www.youtube.com/watch?v=YQHsXMglC9A',
    createdAt: new Date()
  },
  {
    id: 'JGwWNGJdvx8',
    videoId: 'JGwWNGJdvx8',
    title: 'Ed Sheeran - Shape of You (Official Music Video)',
    thumbnail: 'https://img.youtube.com/vi/JGwWNGJdvx8/maxresdefault.jpg',
    channelName: 'Ed Sheeran',
    channel: 'Ed Sheeran',
    channelImage: 'https://img.youtube.com/vi/JGwWNGJdvx8/maxresdefault.jpg',
    views: '6.1B просмотров',
    uploadTime: '7 лет назад',
    duration: '3:54',
    likes: '31M',
    subscribers: '54.1M',
    description: 'Ed Sheeran\'s official music video for \'Shape of You\'',
    videoUrl: 'https://www.youtube.com/watch?v=JGwWNGJdvx8',
    createdAt: new Date()
  },
  {
    id: 'fJ9rUzIMcZQ',
    videoId: 'fJ9rUzIMcZQ',
    title: 'Queen – Bohemian Rhapsody (Official Video Remastered)',
    thumbnail: 'https://img.youtube.com/vi/fJ9rUzIMcZQ/maxresdefault.jpg',
    channelName: 'Queen Official',
    channel: 'Queen Official',
    channelImage: 'https://img.youtube.com/vi/fJ9rUzIMcZQ/maxresdefault.jpg',
    views: '1.9B просмотров',
    uploadTime: '13 лет назад',
    duration: '5:55',
    likes: '12M',
    subscribers: '27.9M',
    description: 'Taken from A Night At The Opera, 1975 and Greatest Video Hits 1.',
    videoUrl: 'https://www.youtube.com/watch?v=fJ9rUzIMcZQ',
    createdAt: new Date()
  },
  {
    id: 'L_jWHffIx5E',
    videoId: 'L_jWHffIx5E',
    title: 'Smash Mouth - All Star (Official Music Video)',
    thumbnail: 'https://img.youtube.com/vi/L_jWHffIx5E/maxresdefault.jpg',
    channelName: 'Smash Mouth',
    channel: 'Smash Mouth',
    channelImage: 'https://img.youtube.com/vi/L_jWHffIx5E/maxresdefault.jpg',
    views: '763M просмотров',
    uploadTime: '14 лет назад',
    duration: '3:21',
    likes: '6.2M',
    subscribers: '1.47M',
    description: 'Official Music Video for All Star by Smash Mouth from the album Astro Lounge',
    videoUrl: 'https://www.youtube.com/watch?v=L_jWHffIx5E',
    createdAt: new Date()
  },
  {
    id: 'v8',
    title: 'Игры 2025: Топ-20 самых ожидаемых релизов года',
    thumbnail: 'https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg',
    channelName: 'Игровой Мир',
    channelImage: 'https://images.pexels.com/photos/2047905/pexels-photo-2047905.jpeg',
    views: '2.3M просмотров',
    uploadTime: '4 дня назад',
    duration: '28:15',
    likes: '187K',
    subscribers: '1.9M',
    description: 'Полный обзор самых ожидаемых игр 2025 года для PC, PlayStation и Xbox. Подробности о датах выхода и геймплее.'
  },
  {
    id: 'v9',
    title: 'Как заработать на криптовалюте в 2025 (Честный обзор)',
    thumbnail: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg',
    channelName: 'Крипто Эксперт',
    channelImage: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg',
    views: '1.1M просмотров',
    uploadTime: '1 неделя назад',
    duration: '19:43',
    likes: '89K',
    subscribers: '850K',
    description: 'Реалистичный взгляд на возможности заработка в криптовалюте в 2025 году. Стратегии, риски и советы новичкам.'
  },
  {
    id: 'v10',
    title: 'Эта простая привычка изменила мою жизнь за 30 дней',
    thumbnail: 'https://images.pexels.com/photos/2422290/pexels-photo-2422290.jpeg',
    channelName: 'Жизнь Лайфхаки',
    channelImage: 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg',
    views: '3.7M просмотров',
    uploadTime: '2 недели назад',
    duration: '14:27',
    likes: '298K',
    subscribers: '2.1M',
    description: 'История о том, как одна простая привычка кардинально изменила мою продуктивность и качество жизни.'
  },
  {
    id: 'v11',
    title: 'Новости: Революция в искусственном интеллекте',
    thumbnail: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg',
    channelName: 'Технологии Сегодня',
    channelImage: 'https://images.pexels.com/photos/2182863/pexels-photo-2182863.jpeg',
    views: '890K просмотров',
    uploadTime: '1 день назад',
    duration: '16:32',
    likes: '67K',
    subscribers: '1.3M',
    description: 'Последние новости в области ИИ: новые модели, прорывы и их влияние на будущее технологий.'
  },
  {
    id: 'v12',
    title: 'Спорт: Чемпионат мира по футболу 2025 - главные события',
    thumbnail: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg',
    channelName: 'Спорт 24/7',
    channelImage: 'https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg',
    views: '1.5M просмотров',
    uploadTime: '6 часов назад',
    duration: '21:18',
    likes: '124K',
    subscribers: '3.2M',
    description: 'Обзор самых захватывающих моментов чемпионата мира, интервью с игроками и прогнозы экспертов.'
  },
  {
    id: 'v13',
    title: 'Подкаст: Интервью с успешным стартапером',
    thumbnail: 'https://images.pexels.com/photos/4050312/pexels-photo-4050312.jpeg',
    channelName: 'Бизнес Подкасты',
    channelImage: 'https://images.pexels.com/photos/1181435/pexels-photo-1181435.jpeg',
    views: '670K просмотров',
    uploadTime: '3 дня назад',
    duration: '45:12',
    likes: '43K',
    subscribers: '780K',
    description: 'Откровенное интервью с основателем успешного технологического стартапа о пути к успеху.'
  },
  {
    id: 'v14',
    title: 'Прямой эфир: Концерт классической музыки из Мариинского театра',
    thumbnail: 'https://images.pexels.com/photos/164938/pexels-photo-164938.jpeg',
    channelName: 'Классическая Музыка Live',
    channelImage: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    views: '234K просмотров',
    uploadTime: 'идет прямой эфир',
    duration: 'LIVE',
    likes: '12K',
    subscribers: '560K',
    description: 'Прямая трансляция концерта симфонического оркестра из Мариинского театра.'
  },
  {
    id: 'v15',
    title: 'React vs Vue vs Angular 2025: Что выбрать?',
    thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg',
    channelImage: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    channelName: 'КодМастер',
    views: '980K просмотров',
    uploadTime: '5 дней назад',
    duration: '24:51',
    likes: '78K',
    subscribers: '1.2M',
    description: 'Подробное сравнение популярных фронтенд фреймворков в 2025 году с практическими примерами.'
  }
];

export const mockShorts = [
  {
    id: 's1',
    title: 'Эта собака умеет решать математические задачи 🤯',
    thumbnail: 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg',
    views: '4.8M'
  },
  {
    id: 's2',
    title: 'Простой способ приготовить ужин за 5 минут',
    thumbnail: 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg',
    views: '2.1M'
  },
  {
    id: 's3',
    title: 'Вы всю жизнь неправильно завязывали шнурки',
    thumbnail: 'https://images.pexels.com/photos/1159670/pexels-photo-1159670.jpeg',
    views: '8.3M'
  },
  {
    id: 's4',
    title: 'Как приготовить идеальный кофе дома',
    thumbnail: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    views: '1.7M'
  },
  {
    id: 's5',
    title: 'Этот трюк улучшит вашу память',
    thumbnail: 'https://images.pexels.com/photos/256431/pexels-photo-256431.jpeg',
    views: '3.5M'
  },
  {
    id: 's6',
    title: 'Новый трюк с iPhone, о котором вы не знали',
    thumbnail: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg',
    views: '5.2M'
  },
  {
    id: 's7',
    title: 'Секрет успешной презентации за 30 секунд',
    thumbnail: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg',
    views: '3.2M'
  },
  {
    id: 's8',
    title: 'Самый вкусный рецепт пиццы за 10 минут',
    thumbnail: 'https://images.pexels.com/photos/365459/pexels-photo-365459.jpeg',
    views: '6.8M'
  },
  {
    id: 's9',
    title: 'Лайфхак для уборки, который изменит вашу жизнь',
    thumbnail: 'https://images.pexels.com/photos/4239013/pexels-photo-4239013.jpeg',
    views: '4.5M'
  },
  {
    id: 's10',
    title: 'Как выучить язык за месяц (работает!)',
    thumbnail: 'https://images.pexels.com/photos/301926/pexels-photo-301926.jpeg',
    views: '7.1M'
  },
  {
    id: 's11',
    title: 'Танец, который покорил TikTok',
    thumbnail: 'https://images.pexels.com/photos/3745234/pexels-photo-3745234.jpeg',
    views: '12.5M'
  },
  {
    id: 's12',
    title: 'Секретная функция Google Maps',
    thumbnail: 'https://images.pexels.com/photos/97080/pexels-photo-97080.jpeg',
    views: '2.9M'
  },
  {
    id: 's13',
    title: 'Реакция кота на новую игрушку',
    thumbnail: 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg',
    views: '9.3M'
  },
  {
    id: 's14',
    title: 'Как похудеть без диет и спорта',
    thumbnail: 'https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg',
    views: '5.7M'
  },
  {
    id: 's15',
    title: 'Невероятные факты о космосе',
    thumbnail: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
    views: '3.4M'
  }
];

export const mockChannels = [
  {
    id: 'c1',
    name: 'КодМастер',
    image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    subscribers: '1.2M'
  },
  {
    id: 'c2',
    name: 'МузыкаНаставник',
    image: 'https://images.pexels.com/photos/1270076/pexels-photo-1270076.jpeg',
    subscribers: '2.8M'
  },
  {
    id: 'c3',
    name: 'Городской Стиль Жизни',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    subscribers: '950K'
  },
  {
    id: 'c4',
    name: 'Кулинарные Приключения',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    subscribers: '3.4M'
  },
  {
    id: 'c5',
    name: 'Инсайдер Путешествий',
    image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
    subscribers: '1.7M'
  },
  {
    id: 'c6',
    name: 'Предприниматель Ежедневно',
    image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
    subscribers: '2.2M'
  },
  {
    id: 'c7',
    name: 'Фокус на Фитнес',
    image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
    subscribers: '4.5M'
  }
];

export const mockPlaylists = [
  {
    id: 'p1',
    title: 'Любимые уроки программирования',
    thumbnail: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg',
    channelName: 'Мой канал',
    videoCount: 14,
    lastUpdated: '2 дня назад'
  },
  {
    id: 'p2',
    title: 'Тренировки',
    thumbnail: 'https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg',
    channelName: 'Мой канал',
    videoCount: 8,
    lastUpdated: '1 неделя назад'
  },
  {
    id: 'p3',
    title: 'Музыка для учебы',
    thumbnail: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    channelName: 'Мой канал',
    videoCount: 23,
    lastUpdated: '3 дня назад'
  }
];