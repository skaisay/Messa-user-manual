import { apiRequest } from "./queryClient";
import type { Video, VideoSearchRequest, YoutubeUrlRequest } from "@shared/schema";

export async function searchVideos(query: string): Promise<Video[]> {
  const data: VideoSearchRequest = { query };
  const response = await apiRequest('POST', '/api/search', data);
  return response.json();
}

export async function getVideoInfo(url: string): Promise<Video> {
  const data: YoutubeUrlRequest = { url };
  const response = await apiRequest('POST', '/api/video', data);
  return response.json();
}

export async function getTrendingVideos(): Promise<Video[]> {
  const response = await apiRequest('GET', '/api/trending');
  return response.json();
}
