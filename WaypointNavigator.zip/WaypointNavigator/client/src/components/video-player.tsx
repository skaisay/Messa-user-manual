import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { getVideoInfo } from "@/lib/video-api";
import { ArrowLeft, Play } from "lucide-react";
import type { Video } from "@shared/schema";

interface VideoPlayerProps {
  video: Video;
  onClose: () => void;
}

export default function VideoPlayer({ video, onClose }: VideoPlayerProps) {
  // Получаем информацию о видео
  const { data: videoData, isLoading, error } = useQuery({
    queryKey: ['/api/video', video.videoId],
    queryFn: async () => {
      const url = `https://www.youtube.com/watch?v=${video.videoId}`;
      return getVideoInfo(url);
    },
  });

  // Предотвращение скролла при открытом плеере
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  if (isLoading) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col">
        <div className="flex items-center justify-between p-4 bg-black/90 backdrop-blur-sm">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-white font-medium text-lg flex-1 mx-4 truncate">
            {video.title}
          </h1>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
            <p>Загрузка видео...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !videoData?.videoUrl) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col">
        <div className="flex items-center justify-between p-4 bg-black/90 backdrop-blur-sm">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-white font-medium text-lg flex-1 mx-4 truncate">
            Ошибка воспроизведения
          </h1>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center">
              <Play className="w-8 h-8" />
            </div>
            <p className="text-lg mb-2">Не удалось загрузить видео</p>
            <p className="text-sm text-gray-400">
              Попробуйте выбрать другое видео
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      {/* Header with close button */}
      <div className="flex items-center justify-between p-4 bg-black/90 backdrop-blur-sm">
        <button
          onClick={onClose}
          className="p-2 rounded-full hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <h1 className="text-white font-medium text-lg flex-1 mx-4 truncate">
          {video.title}
        </h1>
      </div>

      {/* Video container */}
      <div className="flex-1 relative bg-black">
        <iframe
          src={videoData.videoUrl}
          className="w-full h-full"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          title={video.title}
        />
      </div>

      {/* Video info */}
      <div className="p-4 bg-black text-white max-h-40 overflow-y-auto">
        <h2 className="text-lg font-semibold mb-2">{video.title}</h2>
        <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
          <span>{video.channel}</span>
          <div className="flex items-center space-x-4">
            <span>{video.views} просмотров</span>
            <span>{video.uploadTime}</span>
          </div>
        </div>
        {video.description && (
          <p className="text-sm text-gray-300 leading-relaxed">
            {video.description}
          </p>
        )}
      </div>
    </div>
  );
}