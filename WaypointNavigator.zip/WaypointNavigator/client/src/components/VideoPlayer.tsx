import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, ThumbsUp, ThumbsDown, Share, Download, Plus, MoreVertical, Play, Pause } from 'lucide-react';

interface Video {
  id?: number;
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  views?: string | null;
  uploadTime?: string | null;
  duration: string;
  description?: string | null;
  videoUrl?: string | null;
  createdAt?: Date | null;
}

interface VideoPlayerProps {
  video: Video;
  onClose: () => void;
}

export const VideoPlayer = ({ video, onClose }: VideoPlayerProps) => {
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Настройка Media Session API для фонового воспроизведения
  useEffect(() => {
    if ('mediaSession' in navigator && video) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: video.title,
        artist: video.channel,
        album: 'YouTube Music',
        artwork: [
          { src: video.thumbnail, sizes: '96x96', type: 'image/jpeg' },
          { src: video.thumbnail, sizes: '128x128', type: 'image/jpeg' },
          { src: video.thumbnail, sizes: '192x192', type: 'image/jpeg' },
          { src: video.thumbnail, sizes: '256x256', type: 'image/jpeg' },
          { src: video.thumbnail, sizes: '384x384', type: 'image/jpeg' },
          { src: video.thumbnail, sizes: '512x512', type: 'image/jpeg' },
        ]
      });

      // Основные действия воспроизведения
      navigator.mediaSession.setActionHandler('play', handlePlay);
      navigator.mediaSession.setActionHandler('pause', handlePause);
      
      // Навигация между треками
      navigator.mediaSession.setActionHandler('previoustrack', () => {
        console.log('Предыдущий трек');
        // Здесь можно добавить логику перехода к предыдущему видео
      });
      
      navigator.mediaSession.setActionHandler('nexttrack', () => {
        console.log('Следующий трек');
        // Здесь можно добавить логику перехода к следующему видео
      });

      // Перемотка
      navigator.mediaSession.setActionHandler('seekbackward', (details) => {
        if (audioRef.current) {
          const skipTime = details.seekOffset || 10;
          audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - skipTime);
        }
      });

      navigator.mediaSession.setActionHandler('seekforward', (details) => {
        if (audioRef.current) {
          const skipTime = details.seekOffset || 10;
          audioRef.current.currentTime = Math.min(
            audioRef.current.duration || 0, 
            audioRef.current.currentTime + skipTime
          );
        }
      });

      // Точная перемотка по времени
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (audioRef.current && details.seekTime !== undefined) {
          audioRef.current.currentTime = details.seekTime;
        }
      });

      // Остановка
      navigator.mediaSession.setActionHandler('stop', () => {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.currentTime = 0;
          setIsPlaying(false);
        }
      });
    }

    // Автозапуск аудио
    setTimeout(() => {
      handlePlay();
    }, 1000);

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [video]);

  const handlePlay = () => {
    if (audioRef.current) {
      audioRef.current.play();
      setIsPlaying(true);
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'playing';
      }
    }
  };

  const handlePause = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'paused';
      }
    }
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      
      // Обновляем позицию в Media Session
      if ('mediaSession' in navigator) {
        navigator.mediaSession.setPositionState({
          duration: audioRef.current.duration,
          playbackRate: audioRef.current.playbackRate,
          position: audioRef.current.currentTime
        });
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="fixed inset-0 bg-black z-20 flex flex-col text-white pt-4">
      <div className="relative h-56 bg-black">
        <button 
          className="absolute top-3 left-3 z-10 w-8 h-8 flex items-center justify-center bg-black bg-opacity-50 rounded-full"
          onClick={onClose}
        >
          <ArrowLeft size={18} className="text-white" />
        </button>
        
        {/* Скрытый аудио-элемент для фонового воспроизведения */}
        <audio
          ref={audioRef}
          src={`https://www.youtube.com/watch?v=${video.videoId}`}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onEnded={() => setIsPlaying(false)}
          preload="metadata"
        />
        
        {/* Винтажный музыкальный плеер с анимацией диска */}
        <div className="w-full h-full bg-black flex items-center justify-center">
          <div className="flex flex-col items-center group/he select-none">
            <div className="relative z-0 h-16 -mb-2 transition-all duration-200 group-hover/he:h-0">
              <svg
                width="128"
                height="128"
                viewBox="0 0 128 128"
                className={`duration-500 border-4 rounded-full shadow-md border-zinc-400 border-spacing-5 transition-all ${isPlaying ? 'animate-[spin_3s_linear_infinite]' : ''}`}
              >
                <rect width="128" height="128" fill="black"></rect>
                <circle cx="20" cy="20" r="2" fill="white"></circle>
                <circle cx="40" cy="30" r="2" fill="white"></circle>
                <circle cx="60" cy="10" r="2" fill="white"></circle>
                <circle cx="80" cy="40" r="2" fill="white"></circle>
                <circle cx="100" cy="20" r="2" fill="white"></circle>
                <circle cx="120" cy="50" r="2" fill="white"></circle>
                <circle cx="90" cy="30" r="10" fill="white" fillOpacity="0.5"></circle>
                <circle cx="90" cy="30" r="8" fill="white"></circle>
                <path d="M0 128 Q32 64 64 128 T128 128" fill="purple" stroke="black" strokeWidth="1"></path>
                <path d="M0 128 Q32 48 64 128 T128 128" fill="mediumpurple" stroke="black" strokeWidth="1"></path>
                <path d="M0 128 Q32 32 64 128 T128 128" fill="rebeccapurple" stroke="black" strokeWidth="1"></path>
                <path d="M0 128 Q16 64 32 128 T64 128" fill="purple" stroke="black" strokeWidth="1"></path>
                <path d="M64 128 Q80 64 96 128 T128 128" fill="mediumpurple" stroke="black" strokeWidth="1"></path>
              </svg>
              <div className="absolute z-10 w-8 h-8 bg-white border-4 rounded-full shadow-sm border-zinc-400 top-12 left-12"></div>
            </div>
            
            <div className="z-30 flex flex-col w-40 h-20 transition-all duration-300 bg-white shadow-md group-hover/he:h-40 group-hover/he:w-72 rounded-2xl shadow-zinc-400">
              <div className="flex flex-row w-full h-0 group-hover/he:h-20">
                <div className={`relative flex items-center justify-center w-24 h-24 group-hover/he:-top-6 group-hover/he:-left-4 opacity-0 group-hover/he:opacity-100 transition-all duration-100 ${isPlaying ? 'group-hover/he:animate-[spin_3s_linear_infinite]' : ''}`}>
                  <svg width="96" height="96" viewBox="0 0 128 128" className="duration-500 border-4 rounded-full shadow-md border-zinc-400 border-spacing-5">
                    <rect width="128" height="128" fill="black"></rect>
                    <circle cx="20" cy="20" r="2" fill="white"></circle>
                    <circle cx="40" cy="30" r="2" fill="white"></circle>
                    <circle cx="60" cy="10" r="2" fill="white"></circle>
                    <circle cx="80" cy="40" r="2" fill="white"></circle>
                    <circle cx="100" cy="20" r="2" fill="white"></circle>
                    <circle cx="120" cy="50" r="2" fill="white"></circle>
                    <circle cx="90" cy="30" r="10" fill="white" fillOpacity="0.5"></circle>
                    <circle cx="90" cy="30" r="8" fill="white"></circle>
                    <path d="M0 128 Q32 64 64 128 T128 128" fill="purple" stroke="black" strokeWidth="1"></path>
                    <path d="M0 128 Q32 48 64 128 T128 128" fill="mediumpurple" stroke="black" strokeWidth="1"></path>
                    <path d="M0 128 Q32 32 64 128 T128 128" fill="rebeccapurple" stroke="black" strokeWidth="1"></path>
                    <path d="M0 128 Q16 64 32 128 T64 128" fill="purple" stroke="black" strokeWidth="1"></path>
                    <path d="M64 128 Q80 64 96 128 T128 128" fill="mediumpurple" stroke="black" strokeWidth="1"></path>
                  </svg>
                  <div className="absolute z-10 w-6 h-6 bg-white border-4 rounded-full shadow-sm border-zinc-400 top-9 left-9"></div>
                </div>
                <div className="flex flex-col justify-center w-full pl-3 -ml-24 overflow-hidden group-hover/he:-ml-3 text-nowrap">
                  <p className="text-xl font-bold text-black">{video.title.length > 20 ? video.title.substring(0, 20) + '...' : video.title}</p>
                  <p className="text-zinc-600">{video.channel}</p>
                </div>
              </div>
              
              <div className="flex flex-row mx-3 mt-3 bg-indigo-100 rounded-md min-h-4 group-hover/he:mt-0">
                <span className="hidden pl-3 text-sm text-zinc-600 group-hover/he:inline-block">{formatTime(currentTime)}</span>
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  value={currentTime}
                  onChange={(e) => {
                    if (audioRef.current) {
                      audioRef.current.currentTime = Number(e.target.value);
                    }
                  }}
                  className="w-24 group-hover/he:w-full flex-grow h-1 mx-2 my-auto bg-gray-300 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-zinc-400 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-md"
                />
                <span className="hidden pr-3 text-sm text-zinc-600 group-hover/he:inline-block">{formatTime(duration)}</span>
              </div>
              
              <div className="flex flex-row items-center justify-center flex-grow mx-3 space-x-5">
                <div className="flex items-center justify-center w-0 h-full cursor-pointer group-hover/he:w-12">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#777" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="17 1 21 5 17 9"></polyline>
                    <path d="M3 11V9a4 4 0 0 1 4-4h14"></path>
                    <polyline points="7 23 3 19 7 15"></polyline>
                    <path d="M21 13v2a4 4 0 0 1-4 4H3"></path>
                  </svg>
                </div>
                
                <div className="flex items-center justify-center w-12 h-full cursor-pointer">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="19 20 9 12 19 4 19 20"></polygon>
                    <line x1="5" y1="19" x2="5" y2="5"></line>
                  </svg>
                </div>
                
                <div className="flex items-center justify-center w-12 h-full cursor-pointer" onClick={togglePlayPause}>
                  {isPlaying ? (
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="6" y="4" width="4" height="16"></rect>
                      <rect x="14" y="4" width="4" height="16"></rect>
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                  )}
                </div>
                
                <div className="flex items-center justify-center w-12 h-full cursor-pointer">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="5 4 15 12 5 20 5 4"></polygon>
                    <line x1="19" y1="5" x2="19" y2="19"></line>
                  </svg>
                </div>
                
                <div className="flex items-center justify-center w-12 h-full cursor-pointer">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#777" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-0 group-hover/he:w-12">
                    <line x1="8" y1="6" x2="21" y2="6"></line>
                    <line x1="8" y1="12" x2="21" y2="12"></line>
                    <line x1="8" y1="18" x2="21" y2="18"></line>
                    <line x1="3" y1="6" x2="3.01" y2="6"></line>
                    <line x1="3" y1="12" x2="3.01" y2="12"></line>
                    <line x1="3" y1="18" x2="3.01" y2="18"></line>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="px-4 py-3 border-b border-gray-800">
        <h1 className="font-bold text-lg text-white">{video.title}</h1>
        
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-full bg-gray-600 overflow-hidden">
              <div className="w-full h-full bg-gray-600 flex items-center justify-center text-white text-xs">
                {video.channel?.[0]?.toUpperCase() || 'C'}
              </div>
            </div>
            <div className="ml-2">
              <p className="text-sm font-medium text-white">{video.channel}</p>
              <p className="text-xs text-gray-400">подписчиков: не указано</p>
            </div>
          </div>
          
          <button className="bg-red-600 text-white text-sm font-medium px-4 py-1.5 rounded-full">
            Подписаться
          </button>
        </div>
        
        <div className="flex items-center justify-between mt-3 overflow-x-auto scrollbar-hide">
          <div className="flex items-center rounded-full bg-gray-800 mr-2">
            <button className="flex items-center space-x-1 px-3 py-1.5 border-r border-gray-600">
              <ThumbsUp size={18} />
              <span className="text-sm">нравится</span>
            </button>
            <button className="px-3 py-1.5">
              <ThumbsDown size={18} />
            </button>
          </div>
          
          <button className="flex items-center space-x-1 bg-gray-800 rounded-full px-3 py-1.5 mr-2">
            <Share size={18} />
            <span className="text-sm whitespace-nowrap">Поделиться</span>
          </button>
          
          <button className="flex items-center space-x-1 bg-gray-800 rounded-full px-3 py-1.5 mr-2">
            <Download size={18} />
            <span className="text-sm whitespace-nowrap">Скачать</span>
          </button>
          
          <button className="flex items-center space-x-1 bg-gray-800 rounded-full px-3 py-1.5 mr-2">
            <Plus size={18} />
            <span className="text-sm whitespace-nowrap">Сохранить</span>
          </button>
          
          <button className="p-2 rounded-full bg-gray-800">
            <MoreVertical size={18} />
          </button>
        </div>
      </div>
      
      <div 
        className={`px-4 py-3 border-b border-gray-800 ${!isDescriptionExpanded ? 'max-h-20 overflow-hidden' : ''}`}
        onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
      >
        <div className="text-sm">
          <p className="text-gray-300 font-medium">
            {video.views || '0 просмотров'} • {video.uploadTime || 'недавно'}
          </p>
          <p className="mt-2 whitespace-pre-line text-white">
            {video.description || 'Описание отсутствует'}
          </p>
        </div>
        {!isDescriptionExpanded && (
          <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-black to-transparent"></div>
        )}
      </div>
      
      <div className="px-4 py-3 flex-1 overflow-y-auto">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-white">Комментарии</h3>
          <button>
            <MoreVertical size={18} />
          </button>
        </div>
        
        <div className="flex items-start mb-6">
          <div className="h-8 w-8 rounded-full bg-gray-600 flex-shrink-0 overflow-hidden">
            <div className="w-full h-full bg-gray-600 flex items-center justify-center text-white text-xs">
              U
            </div>
          </div>
          
          <div className="ml-3 flex-1">
            <div className="flex items-center">
              <p className="text-sm font-medium text-white">Пользователь123</p>
              <p className="text-xs text-gray-400 ml-2">2 дня назад</p>
            </div>
            <p className="text-sm mt-1 text-white">
              Отличное видео! Спасибо за качественный контент.
            </p>
            <div className="flex items-center mt-1 text-gray-400">
              <button className="flex items-center mr-4">
                <ThumbsUp size={14} />
                <span className="text-xs ml-1">42</span>
              </button>
              <button>
                <ThumbsDown size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};