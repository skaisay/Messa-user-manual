interface YouTubeHeaderProps {
  onMenuClick: () => void;
  onSearchClick: () => void;
}

export default function YouTubeHeader({ onMenuClick, onSearchClick }: YouTubeHeaderProps) {
  return (
    <header className="youtube-header">
      <div className="youtube-logo">
        <i className="fab fa-youtube"></i>
        <span>YouTube</span>
      </div>
      
      <button 
        className="search-button" 
        onClick={onSearchClick}
        aria-label="Поиск"
      >
        <i className="fas fa-search"></i>
      </button>
    </header>
  );
}
