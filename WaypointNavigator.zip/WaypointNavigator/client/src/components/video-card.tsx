import type { Video } from "@shared/schema";

interface VideoCardProps {
  video: Video;
  onClick: () => void;
}

export default function VideoCard({ video, onClick }: VideoCardProps) {
  return (
    <div className="video-card" onClick={onClick}>
      <div className="video-thumbnail">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          loading="lazy"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwIiBoZWlnaHQ9IjY4IiB2aWV3Qm94PSIwIDAgMTIwIDY4IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMjAiIGhlaWdodD0iNjgiIGZpbGw9IiMzMzMiLz48dGV4dCB4PSI2MCIgeT0iMzQiIGZpbGw9IiM2NjYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGFsaWdubWVudC1iYXNlbGluZT0ibWlkZGxlIiBmb250LXNpemU9IjEyIj5Ошибка загрузки</dGV4dD48L3N2Zz4=';
          }}
        />
        {video.duration && (
          <div className="video-duration">{video.duration}</div>
        )}
      </div>
      
      <div className="video-info">
        <div className="video-title">{video.title}</div>
        <div className="video-meta">
          <div className="video-channel">{video.channel}</div>
          <div className="video-stats">
            {video.views && <span>{video.views} просмотров</span>}
            {video.views && video.uploadTime && <span>•</span>}
            {video.uploadTime && <span>{video.uploadTime}</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
