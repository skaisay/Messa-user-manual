import { Home, Search } from "lucide-react";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const navItems = [
    { id: 'home', icon: Home, label: 'Главная' },
    { id: 'search', icon: Search, label: 'Поиск' },
  ];

  return (
    <nav className="bottom-navigation">
      {navItems.map((item) => {
        const IconComponent = item.icon;
        return (
          <div 
            key={item.id}
            className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => onTabChange(item.id)}
          >
            <IconComponent className={`w-6 h-6 ${activeTab === item.id ? 'text-red-600' : 'text-white'}`} />
            <span className={activeTab === item.id ? 'text-red-600' : 'text-white'}>{item.label}</span>
          </div>
        );
      })}
    </nav>
  );
}