import { useEffect } from "react";

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onMenuClick: (page: string) => void;
}

export default function MobileSidebar({ isOpen, onClose, onMenuClick }: MobileSidebarProps) {
  // Обработка свайпов
  useEffect(() => {
    let touchStartX = 0;
    let touchEndX = 0;

    const handleTouchStart = (e: TouchEvent) => {
      touchStartX = e.changedTouches[0].screenX;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      touchEndX = e.changedTouches[0].screenX;
      const swipeDistance = touchEndX - touchStartX;
      
      if (swipeDistance < -100 && isOpen) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('touchstart', handleTouchStart);
      document.addEventListener('touchend', handleTouchEnd);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchend', handleTouchEnd);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  const menuItems = [
    { id: 'home', icon: 'fas fa-home', label: 'Главная' },
    { id: 'trending', icon: 'fas fa-fire', label: 'В тренде' },
    { id: 'subscriptions', icon: 'fas fa-play-circle', label: 'Подписки' },
    { id: 'library', icon: 'fas fa-folder', label: 'Моя медиатека' },
    { id: 'history', icon: 'fas fa-history', label: 'История' },
    { id: 'liked', icon: 'fas fa-thumbs-up', label: 'Понравившиеся' },
    { id: 'watchlater', icon: 'fas fa-clock', label: 'Посмотреть позже' },
    { id: 'settings', icon: 'fas fa-cog', label: 'Настройки' },
  ];

  return (
    <nav className={`mobile-sidebar ${isOpen ? 'open' : ''}`}>
      <div className="p-4 border-b border-[#333] flex items-center gap-3">
        <button 
          className="bg-transparent border-none text-white text-xl p-2 rounded-full cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
          onClick={onClose}
          aria-label="Закрыть меню"
        >
          <i className="fas fa-times"></i>
        </button>
        <div className="text-lg font-semibold">Мобильное Видео</div>
      </div>
      
      <ul className="py-2 list-none">
        {menuItems.map((item) => (
          <li 
            key={item.id}
            className="px-4 py-3 cursor-pointer flex items-center gap-4 transition-colors hover:bg-[#333]"
            onClick={() => onMenuClick(item.id)}
          >
            <i className={`${item.icon} w-6 text-center text-[#aaa]`}></i>
            <span>{item.label}</span>
          </li>
        ))}
      </ul>
    </nav>
  );
}
