import { Youtube } from 'lucide-react';

export const Logo = () => {
  return (
    <div className="flex items-center">
      <Youtube size={28} className="text-red-600" />
      <span className="ml-1 text-lg font-semibold text-white">YouTube</span>
    </div>
  );
};