import { useState } from 'react';
import { Search, Mic, BellRing, User, X } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  onSearch?: (query: string) => void;
  onCategoryChange?: (category: string) => void;
}

export const Header = ({ onSearch, onCategoryChange }: HeaderProps) => {
  const [isSearchActive, setIsSearchActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCategories, setShowCategories] = useState(true);

  return (
    <header className="sticky top-0 z-10 bg-black shadow-sm">
      {!isSearchActive ? (
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-2">
            <Logo />
            <span className="text-gray-400 text-sm ml-1">8</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              className="p-2 rounded-full hover:bg-gray-800 text-white"
              onClick={() => setIsSearchActive(true)}
            >
              <Search size={22} />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-800 text-white">
              <Mic size={22} />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-800 text-white">
              <BellRing size={22} />
            </button>
            <button className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center">
              <User size={18} />
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center h-16 px-2">
          <button 
            className="p-2 rounded-full hover:bg-gray-800 mr-2 text-white"
            onClick={() => setIsSearchActive(false)}
          >
            <span className="text-xl font-bold">←</span>
          </button>
          <div className="flex-1 flex items-center bg-gray-800 rounded-full px-4 h-10">
            <Search size={18} className="text-gray-400 mr-2" />
            <input 
              type="text" 
              placeholder="Поиск на YouTube" 
              className="flex-1 bg-transparent border-none outline-none text-white placeholder-gray-400" 
              autoFocus
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && onSearch && searchQuery.trim()) {
                  onSearch(searchQuery.trim());
                }
              }}
            />
            {searchQuery.trim() && (
              <button 
                className="ml-2 text-blue-400 hover:text-blue-300 text-sm font-medium"
                onClick={() => {
                  if (onSearch && searchQuery.trim()) {
                    onSearch(searchQuery.trim());
                  }
                }}
              >
                Найти
              </button>
            )}
          </div>
        </div>
      )}

      {!isSearchActive && showCategories && (
        <div className="flex items-center overflow-x-auto scrollbar-hide px-4 py-2 pb-6 space-x-3 border-b border-gray-800">
          <button 
            className="whitespace-nowrap bg-white text-black rounded-lg text-sm px-3 py-1.5 font-medium"
            onClick={() => onCategoryChange?.('all')}
          >
            Все
          </button>
          <button 
            className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium"
            onClick={() => onCategoryChange?.('music')}
          >
            Музыка
          </button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">Игры</button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">Подкасты</button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">Прямой эфир</button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">Новости</button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">Спорт</button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">React</button>
          <button className="whitespace-nowrap bg-gray-800 text-white rounded-lg text-sm px-3 py-1.5 font-medium">JavaScript</button>
          <button 
            className="whitespace-nowrap p-2 rounded-full hover:bg-gray-800 text-gray-400"
            onClick={() => setShowCategories(false)}
          >
            <X size={16} />
          </button>
        </div>
      )}
    </header>
  );
};