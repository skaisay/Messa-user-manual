interface Video {
  id?: number;
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  views?: string | null;
  uploadTime?: string | null;
  duration: string;
  description?: string | null;
  videoUrl?: string | null;
  createdAt?: Date | null;
}

interface VideoCardProps {
  video: Video;
  onVideoClick: (video: Video) => void;
}

export const VideoCard = ({ video, onVideoClick }: VideoCardProps) => {
  return (
    <div className="mb-4" onClick={() => onVideoClick(video)}>
      <div className="relative pb-[56.25%] bg-gray-800 rounded-xl overflow-hidden">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="absolute top-0 left-0 w-full h-full object-cover"
        />
        <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
          {video.duration}
        </div>
      </div>
      
      <div className="flex mt-2 px-2">
        <div className="h-9 w-9 rounded-full bg-gray-600 flex-shrink-0 overflow-hidden">
          <div className="w-full h-full bg-gray-600 flex items-center justify-center text-white text-xs">
            {video.channel?.[0]?.toUpperCase() || 'C'}
          </div>
        </div>
        
        <div className="ml-3 flex-1">
          <h3 className="font-medium text-sm line-clamp-2 text-white">
            {video.title}
          </h3>
          <p className="text-gray-400 text-xs mt-1">
            {video.channel}
          </p>
          <p className="text-gray-400 text-xs">
            {video.views || '0 просмотров'} • {video.uploadTime || 'недавно'}
          </p>
        </div>
      </div>
    </div>
  );
};