import { Home as HomeIcon, Play, Plus, Users, Library } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Navigation = ({ activeTab, onTabChange }: NavigationProps) => {
  const tabs = [
    { id: 'home', icon: HomeIcon, label: 'Главная' },
    { id: 'shorts', icon: Play, label: 'Shorts' },
    { id: 'create', icon: Plus, label: '' },
    { id: 'subscriptions', icon: Users, label: 'Подписки' },
    { id: 'library', icon: Library, label: 'Коллекция' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 h-18 flex items-center z-10">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className="flex-1 flex flex-col items-center justify-center h-full text-white mt-[-2px] mb-[-2px] pt-[8px] pb-[8px]"
          onClick={() => tab.id !== 'create' && onTabChange(tab.id)}
        >
          {tab.id === 'create' ? (
            <div className="flex items-center justify-center w-10 h-10 bg-white rounded-full">
              <tab.icon size={22} className="text-black" />
            </div>
          ) : (
            <>
              <tab.icon size={22} />
              <span className="text-xs pt-[3px] pb-[3px] mt-[6px] mb-[6px]">{tab.label}</span>
            </>
          )}
        </button>
      ))}
    </nav>
  );
};