import { VideoCard } from '../components/VideoCard';
import { useQuery } from '@tanstack/react-query';
import { getTrendingVideos, searchVideos } from '../lib/video-api';

interface Video {
  id?: number;
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  views?: string | null;
  uploadTime?: string | null;
  duration: string;
  description?: string | null;
  videoUrl?: string | null;
  createdAt?: Date | null;
}

interface HomeProps {
  onVideoClick: (video: Video) => void;
  searchQuery?: string;
  categoryFilter?: string;
}

export const Home = ({ onVideoClick, searchQuery, categoryFilter }: HomeProps) => {
  // Если есть поисковый запрос, используем поиск, иначе показываем популярные видео
  const { data: videos = [], isLoading } = useQuery({
    queryKey: searchQuery ? ['/api/search', searchQuery] : ['/api/trending'],
    queryFn: () => searchQuery ? searchVideos(searchQuery) : getTrendingVideos(),
    enabled: true,
  });

  // Фильтрация видео по категориям
  const filteredVideos = videos.filter((video: Video) => {
    // Фильтр по категории
    if (!categoryFilter || categoryFilter === 'all') return true;
    
    if (categoryFilter === 'music') {
      return video.title.toLowerCase().includes('music') ||
             video.title.toLowerCase().includes('song') ||
             video.title.toLowerCase().includes('official') ||
             video.channel.toLowerCase().includes('music') ||
             video.channel.toLowerCase().includes('official') ||
             video.channel.toLowerCase().includes('records') ||
             video.videoId === 'dQw4w9WgXcQ' || // Rick Astley
             video.videoId === '9bZkp7q19f0' || // PSY
             video.videoId === 'kJQP7kiw5Fk' || // Despacito  
             video.videoId === 'fJ9rUzIMcZQ' || // Bohemian Rhapsody
             video.videoId === 'YQHsXMglC9A' || // Adele - Hello
             video.videoId === 'hT_nvWreIhg' || // The Weeknd - Blinding Lights
             video.videoId === 'JGwWNGJdvx8';   // Ed Sheeran - Shape of You
    }
    
    return true;
  });

  if (isLoading) {
    return (
      <div className="p-4">
        <div className="space-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-800 aspect-video rounded-xl mb-2"></div>
              <div className="flex">
                <div className="w-9 h-9 bg-gray-800 rounded-full mr-3"></div>
                <div className="flex-1">
                  <div className="bg-gray-800 h-4 rounded mb-1"></div>
                  <div className="bg-gray-800 h-3 rounded w-3/4"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      {searchQuery && searchQuery.trim() !== '' && (
        <div className="text-gray-300 text-sm mb-4">
          Результаты поиска для "{searchQuery}" ({filteredVideos.length} видео)
        </div>
      )}
      <div className="space-y-1">
        {filteredVideos.map((video: Video) => (
          <VideoCard 
            key={video.videoId} 
            video={video} 
            onVideoClick={onVideoClick}
          />
        ))}
        {filteredVideos.length === 0 && searchQuery && searchQuery.trim() !== '' && (
          <div className="text-center text-gray-400 py-8">
            Ничего не найдено по запросу "{searchQuery}"
          </div>
        )}
      </div>
    </div>
  );
};