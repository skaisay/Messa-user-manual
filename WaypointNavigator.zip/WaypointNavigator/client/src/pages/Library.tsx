import { VideoCard } from '../components/VideoCard';
import { useQuery } from '@tanstack/react-query';
import { getTrendingVideos } from '../lib/video-api';

interface Video {
  id?: number;
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  views?: string | null;
  uploadTime?: string | null;
  duration: string;
  description?: string | null;
  videoUrl?: string | null;
  createdAt?: Date | null;
}

interface LibraryProps {
  onVideoClick: (video: Video) => void;
  searchQuery?: string;
}

export const Library = ({ onVideoClick, searchQuery }: LibraryProps) => {
  const { data: videos = [], isLoading } = useQuery({
    queryKey: ['/api/trending'],
    queryFn: getTrendingVideos,
  });

  if (isLoading) {
    return (
      <div className="p-4">
        <div className="space-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-800 aspect-video rounded-xl mb-2"></div>
              <div className="flex">
                <div className="w-9 h-9 bg-gray-800 rounded-full mr-3"></div>
                <div className="flex-1">
                  <div className="bg-gray-800 h-4 rounded mb-1"></div>
                  <div className="bg-gray-800 h-3 rounded w-3/4"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold text-white mb-4">Коллекция</h2>
      <div className="space-y-1">
        {videos.map((video: Video) => (
          <VideoCard 
            key={video.videoId} 
            video={video} 
            onVideoClick={onVideoClick}
          />
        ))}
      </div>
    </div>
  );
};