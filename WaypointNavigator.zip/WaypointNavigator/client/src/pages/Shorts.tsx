export const Shorts = () => {
  const mockShorts = [
    {
      id: 1,
      title: "Быстрые советы по React",
      thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=600&fit=crop",
      duration: "0:45",
      views: "1.2М просмотров"
    },
    {
      id: 2,
      title: "JavaScript за 60 секунд",
      thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=600&fit=crop",
      duration: "1:00",
      views: "850К просмотров"
    },
    {
      id: 3,
      title: "CSS трюки для начинающих",
      thumbnail: "https://images.unsplash.com/photo-1545665277-5937489579f2?w=400&h=600&fit=crop",
      duration: "0:30",
      views: "2.1М просмотров"
    }
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold text-white mb-4">Shorts</h2>
      <div className="grid grid-cols-2 gap-3">
        {mockShorts.map((short) => (
          <div key={short.id} className="relative">
            <div className="relative aspect-[9/16] bg-gray-800 rounded-xl overflow-hidden">
              <img 
                src={short.thumbnail} 
                alt={short.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
                {short.duration}
              </div>
            </div>
            <div className="mt-2">
              <h3 className="text-sm font-medium text-white line-clamp-2">
                {short.title}
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                {short.views}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};