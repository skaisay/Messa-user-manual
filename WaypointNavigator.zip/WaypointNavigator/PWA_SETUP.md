# Progressive Web App (PWA) Конфигурация

## Полноэкранный режим без интерфейса браузера

Приложение настроено для запуска в полноэкранном режиме на всех платформах.

### iOS Safari

**Мета-теги для полноэкранного режима:**
```html
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<meta name="apple-mobile-web-app-title" content="YouTube" />
<meta name="apple-touch-fullscreen" content="yes" />
```

**Установка на iOS:**
1. Откройте приложение в Safari
2. Нажмите кнопку "Поделиться" (квадрат со стрелкой)
3. Выберите "На экран 'Домой'"
4. Приложение откроется в полноэкранном режиме без панелей Safari

### Android Chrome

**Мета-теги для полноэкранного режима:**
```html
<meta name="mobile-web-app-capable" content="yes" />
<meta name="theme-color" content="#000000" />
```

**Установка на Android:**
1. Откройте приложение в Chrome
2. Нажмите меню (три точки)
3. Выберите "Добавить на главный экран"
4. Приложение откроется в полноэкранном режиме

### Microsoft Edge

**Мета-теги:**
```html
<meta name="msapplication-navbutton-color" content="#000000" />
<meta name="msapplication-TileColor" content="#000000" />
```

## Manifest.json настройки

```json
{
  "display": "fullscreen",
  "display_override": ["fullscreen", "standalone", "minimal-ui", "browser"],
  "background_color": "#000000",
  "theme_color": "#000000"
}
```

**Режимы отображения:**
- `fullscreen` - полноэкранный режим без UI браузера
- `standalone` - как нативное приложение с системной строкой состояния
- `minimal-ui` - минимальный UI браузера
- `browser` - обычный браузер (fallback)

## Иконки для всех устройств

### Стандартные иконки PWA
- `icon-72x72.png` - Android малые иконки
- `icon-96x96.png` - Android средние иконки
- `icon-128x128.png` - Chrome Web Store
- `icon-144x144.png` - Windows Tiles
- `icon-152x152.png` - iPad
- `icon-192x192.png` - Android большие иконки (основная)
- `icon-384x384.png` - Android очень большие иконки
- `icon-512x512.png` - Android максимальные иконки

### iOS специфичные иконки
- `apple-touch-icon.png` (180x180) - iPhone/iPad главная
- `icon-57x57.png` - iPhone 3G/3GS
- `icon-60x60.png` - iPhone 4/4S
- `icon-72x72.png` - iPad 1/2
- `icon-76x76.png` - iPad Air/Mini
- `icon-114x114.png` - iPhone 4/4S Retina
- `icon-120x120.png` - iPhone 5/6/7/8
- `icon-144x144.png` - iPad 3/4 Retina
- `icon-152x152.png` - iPad Air/Mini Retina

## Service Worker для оффлайн режима

**Основные функции:**
- Кэширование статических ресурсов
- Оффлайн поддержка
- Фоновая синхронизация
- Push уведомления

**Стратегии кэширования:**
1. **Cache First** - для статических ресурсов
2. **Network First** - для API запросов
3. **Stale While Revalidate** - для динамического контента

## Специфичные требования для iOS

### 1. Viewport настройка
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
```

### 2. Status Bar стиль
- `default` - черный текст на светлом фоне
- `black` - белый текст на черном фоне
- `black-translucent` - прозрачная строка состояния

### 3. Splash Screens (опционально)
iOS может отображать кастомные splash screen'ы при запуске:
```html
<link rel="apple-touch-startup-image" href="/splash-1125x2436.png" media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3)" />
```

## Рекомендации по оптимизации

### 1. Размеры иконок
- Минимум: 192x192px для Android
- Рекомендуемо: 512x512px для всех платформ
- iOS: кратные 57px (57, 114, 171, etc.)

### 2. Форматы
- PNG для совместимости
- SVG для масштабируемости
- ICO для favicon

### 3. Цветовая схема
- Используйте контрастные цвета
- Учитывайте темную/светлую темы
- Соответствие бренду приложения

### 4. Тестирование
- Chrome DevTools > Application > Manifest
- Lighthouse PWA аудит
- Реальные устройства iOS/Android

## Дополнительные возможности

### Push уведомления
```javascript
// Запрос разрешения
await Notification.requestPermission();

// Отправка уведомления
self.registration.showNotification('Заголовок', {
  body: 'Текст уведомления',
  icon: '/icon-192x192.png'
});
```

### Фоновая синхронизация
```javascript
// Регистрация фоновой синхронизации
await self.registration.sync.register('background-sync');
```

### Shortcuts (ярлыки)
Добавлены в manifest.json для быстрого доступа к основным функциям:
- Популярные видео
- Поиск видео

## Отладка PWA

### Chrome DevTools
1. F12 > Application
2. Manifest - проверка манифеста
3. Service Workers - статус SW
4. Storage - проверка кэша

### iOS Safari
1. Настройки > Safari > Дополнения > Web Inspector
2. Подключите устройство к Mac
3. Safari > Разработка > [Устройство] > [Страница]

### Проверка установки
```javascript
// Проверка, запущено ли как PWA
if (window.matchMedia('(display-mode: standalone)').matches) {
  console.log('Запущено как PWA');
}

// Проверка на iOS
if (window.navigator.standalone) {
  console.log('Запущено как PWA на iOS');
}
```