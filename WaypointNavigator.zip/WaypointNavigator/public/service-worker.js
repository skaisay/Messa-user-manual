const CACHE_NAME = 'youtube-offline-v1';
const STATIC_CACHE = 'static-v1';
const DYNAMIC_CACHE = 'dynamic-v1';

// Ресурсы для кэширования при установке
const staticAssets = [
  '/',
  '/index.html',
  '/manifest.json',
  '/static/js/bundle.js',
  '/static/css/main.css'
];

// Установка Service Worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      caches.open(STATIC_CACHE).then(cache => cache.addAll(staticAssets)),
      caches.open(CACHE_NAME)
    ])
  );
  self.skipWaiting();
});

// Активация Service Worker
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME && cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Перехват запросов
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }

        // Если это API запрос
        if (event.request.url.includes('/api/')) {
          return handleOfflineAPI(event.request);
        }

        // Пытаемся получить из сети и кэшируем
        return fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              const responseClone = networkResponse.clone();
              caches.open(DYNAMIC_CACHE).then(cache => {
                cache.put(event.request, responseClone);
              });
            }
            return networkResponse;
          })
          .catch(() => {
            // Если нет сети, возвращаем офлайн-страницу для HTML запросов
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('/');
            }
          });
      })
  );
});

// Обработка API запросов в офлайне с реальными музыкальными данными
function handleOfflineAPI(request) {
  const offlineData = {
    '/api/trending': [
      {
        id: 1,
        videoId: 'dQw4w9WgXcQ',
        title: 'Rick Astley - Never Gonna Give You Up',
        thumbnail: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
        duration: '3:33',
        channel: 'Rick Astley',
        views: '1.4B просмотров',
        uploadTime: '14 лет назад',
        description: 'Классическая песня от Rick Astley',
        videoUrl: null,
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        videoId: 'kJQP7kiw5Fk',
        title: 'Despacito - Luis Fonsi ft. Daddy Yankee',
        thumbnail: 'https://i.ytimg.com/vi/kJQP7kiw5Fk/maxresdefault.jpg',
        duration: '4:42',
        channel: 'Luis Fonsi',
        views: '8.1B просмотров',
        uploadTime: '7 лет назад',
        description: 'Самое популярное видео на YouTube',
        videoUrl: null,
        createdAt: new Date().toISOString()
      },
      {
        id: 3,
        videoId: 'fJ9rUzIMcZQ',
        title: 'Queen - Bohemian Rhapsody',
        thumbnail: 'https://i.ytimg.com/vi/fJ9rUzIMcZQ/maxresdefault.jpg',
        duration: '5:55',
        channel: 'Queen Official',
        views: '1.9B просмотров',
        uploadTime: '13 лет назад',
        description: 'Легендарная песня группы Queen',
        videoUrl: null,
        createdAt: new Date().toISOString()
      },
      {
        id: 4,
        videoId: 'L_jWHffIx5E',
        title: 'Smash Mouth - All Star',
        thumbnail: 'https://i.ytimg.com/vi/L_jWHffIx5E/maxresdefault.jpg',
        duration: '3:20',
        channel: 'Smash Mouth',
        views: '654M просмотров',
        uploadTime: '12 лет назад',
        description: 'Культовая песня из Shrek',
        videoUrl: null,
        createdAt: new Date().toISOString()
      },
      {
        id: 5,
        videoId: 'y6120QOlsfU',
        title: 'Darude - Sandstorm',
        thumbnail: 'https://i.ytimg.com/vi/y6120QOlsfU/maxresdefault.jpg',
        duration: '3:44',
        channel: 'Darude',
        views: '278M просмотров',
        uploadTime: '11 лет назад',
        description: 'Легендарный электронный трек',
        videoUrl: null,
        createdAt: new Date().toISOString()
      }
    ]
  };
  
  const url = new URL(request.url);
  const data = offlineData[url.pathname] || [];
  
  return new Response(JSON.stringify(data), {
    headers: { 
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }
  });
}