import { Video } from '../../shared/schema';

export interface YouTubeSearchService {
  search(query: string): Promise<Video[]>;
  getVideoInfo(videoId: string): Promise<Video | null>;
  getTrending(): Promise<Video[]>;
}

export class MultiAPIYouTubeService implements YouTubeSearchService {
  private rapidApiKey?: string;

  constructor() {
    this.rapidApiKey = process.env.RAPID_API_KEY;
  }

  async search(query: string): Promise<Video[]> {
    console.log(`Поиск видео: "${query}"`);

    // Пробуем Piped API (бесплатный)
    try {
      const videos = await this.searchPiped(query);
      if (videos.length > 0) {
        console.log(`Piped API: найдено ${videos.length} видео`);
        return videos;
      }
    } catch (error) {
      console.log('Piped API недоступен:', error);
    }

    // Пробуем RapidAPI (если есть ключ)
    if (this.rapidApiKey) {
      try {
        const videos = await this.searchRapidAPI(query);
        if (videos.length > 0) {
          console.log(`RapidAPI: найдено ${videos.length} видео`);
          return videos;
        }
      } catch (error) {
        console.log('RapidAPI недоступен:', error);
      }
    }

    throw new Error('Все YouTube API недоступны. Требуется настройка API ключей.');
  }

  private async searchPiped(query: string): Promise<Video[]> {
    const response = await fetch(
      `https://pipedapi.kavin.rocks/search?q=${encodeURIComponent(query)}&filter=videos`,
      { timeout: 5000 } as any
    );

    if (!response.ok) {
      throw new Error(`Piped API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.items || data.items.length === 0) {
      return [];
    }

    return data.items.slice(0, 12).map((item: any) => ({
      videoId: this.extractVideoId(item.url) || 'unknown',
      title: item.title || 'Без названия',
      thumbnail: item.thumbnail || `https://img.youtube.com/vi/${this.extractVideoId(item.url)}/maxresdefault.jpg`,
      duration: this.formatDuration(item.duration) || '0:00',
      channel: item.uploaderName || 'Неизвестный канал',
      views: this.formatViews(item.views) || '0',
      uploadTime: item.uploadedDate || 'Неизвестно',
      description: item.shortDescription || '',
      videoUrl: `https://www.youtube.com/watch?v=${this.extractVideoId(item.url)}`,
      createdAt: new Date()
    }));
  }

  private async searchRapidAPI(query: string): Promise<Video[]> {
    if (!this.rapidApiKey) {
      throw new Error('RapidAPI key not available');
    }

    const response = await fetch(
      `https://youtube-search-and-download.p.rapidapi.com/search?query=${encodeURIComponent(query)}`,
      {
        headers: {
          'X-RapidAPI-Key': this.rapidApiKey,
          'X-RapidAPI-Host': 'youtube-search-and-download.p.rapidapi.com'
        },
        timeout: 5000
      } as any
    );

    if (!response.ok) {
      throw new Error(`RapidAPI error: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.contents || data.contents.length === 0) {
      return [];
    }

    const videos = data.contents.filter((item: any) => item.video).slice(0, 12);
    
    return videos.map((item: any) => ({
      videoId: item.video.videoId,
      title: item.video.title,
      thumbnail: item.video.thumbnails[0]?.url || `https://img.youtube.com/vi/${item.video.videoId}/maxresdefault.jpg`,
      duration: item.video.lengthText || '0:00',
      channel: item.video.channelName || 'Неизвестный канал',
      views: item.video.viewCountText || '0',
      uploadTime: item.video.publishedTimeText || 'Неизвестно',
      description: item.video.descriptionSnippet || '',
      videoUrl: `https://www.youtube.com/watch?v=${item.video.videoId}`,
      createdAt: new Date()
    }));
  }

  async getVideoInfo(videoId: string): Promise<Video | null> {
    try {
      const response = await fetch(
        `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
      );

      if (response.ok) {
        const data = await response.json();
        return {
          videoId,
          title: data.title,
          thumbnail: data.thumbnail_url,
          channel: data.author_name,
          duration: '0:00',
          views: null,
          uploadTime: null,
          description: null,
          videoUrl: `https://www.youtube.com/watch?v=${videoId}`,
          createdAt: new Date()
        };
      }
    } catch (error) {
      console.error('Ошибка получения информации о видео:', error);
    }

    return null;
  }

  async getTrending(): Promise<Video[]> {
    throw new Error('Для получения популярных видео требуется настройка YouTube API');
  }

  private extractVideoId(url: string): string | null {
    if (!url) return null;
    const match = url.match(/[?&]v=([^&]+)/);
    return match ? match[1] : url.replace('/watch?v=', '');
  }

  private formatDuration(seconds: number | string): string {
    if (!seconds) return '0:00';
    
    const num = typeof seconds === 'string' ? parseInt(seconds) : seconds;
    if (isNaN(num)) return '0:00';
    
    const hours = Math.floor(num / 3600);
    const minutes = Math.floor((num % 3600) / 60);
    const secs = num % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  }

  private formatViews(views: number | string): string {
    if (!views) return '0';
    
    const num = typeof views === 'string' ? parseInt(views.replace(/\D/g, '')) : views;
    if (isNaN(num)) return '0';
    
    if (num >= 1000000000) {
      return `${(num / 1000000000).toFixed(1)}B`;
    } else if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  }
}

export const youtubeService = new MultiAPIYouTubeService();