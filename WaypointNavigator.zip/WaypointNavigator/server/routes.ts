import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { videoSearchSchema, youtubeUrlSchema } from "@shared/schema";
import { youtubeService } from "./services/youtube";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Временный маршрут для обхода кеша браузера
  app.get('/app', (req, res) => {
    res.redirect('/');
  });
  // Search videos using demo data
  app.post("/api/search", async (req, res) => {
    try {
      const { query } = videoSearchSchema.parse(req.body);
      
      // First check local storage
      const localResults = await storage.searchVideos(query);
      
      if (localResults.length > 0) {
        return res.json(localResults);
      }

      // Use demo search data
      const searchResults = await searchExternalVideos(query);
      
      // Save results to storage
      for (const video of searchResults) {
        await storage.createVideo(video);
        await storage.saveSearchResult({
          query,
          videoId: video.videoId
        });
      }

      res.json(searchResults);
    } catch (error) {
      console.error('Search error:', error);
      res.status(500).json({ error: 'Ошибка поиска видео' });
    }
  });

  // Get video metadata and stream URL
  app.post("/api/video", async (req, res) => {
    try {
      const { url } = youtubeUrlSchema.parse(req.body);
      
      const videoId = extractVideoId(url);
      if (!videoId) {
        return res.status(400).json({ error: 'Неверная ссылка на видео' });
      }

      // Check if video already exists
      let video = await storage.getVideo(videoId);
      
      if (!video) {
        // Use yt-dlp to get video info and direct URL
        video = await getVideoInfo(videoId);
        if (video) {
          await storage.createVideo(video);
        }
      }

      if (!video) {
        return res.status(404).json({ error: 'Видео не найдено' });
      }

      res.json(video);
    } catch (error) {
      console.error('Video fetch error:', error);
      res.status(500).json({ error: 'Ошибка загрузки видео' });
    }
  });

  // Get trending/popular videos
  app.get("/api/trending", async (req, res) => {
    try {
      const trendingVideos = await getTrendingVideos();
      res.json(trendingVideos);
    } catch (error) {
      console.error('Trending videos error:', error);
      res.status(500).json({ error: 'Ошибка загрузки популярных видео' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function searchExternalVideos(query: string) {
  try {
    const videos = await youtubeService.search(query);
    return videos;
  } catch (error) {
    console.error('Ошибка поиска через YouTube API:', error);
    throw error;
  }
}

async function getVideoInfo(videoId: string) {
  try {
    // Бесплатное получение информации о видео через oEmbed
    const oEmbedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
    
    const response = await fetch(oEmbedUrl);
    
    if (!response.ok) {
      throw new Error(`oEmbed error: ${response.status}`);
    }

    const data = await response.json();

    return {
      id: 0, // Will be set by storage
      videoId: videoId,
      title: data.title || `Видео ${videoId}`,
      thumbnail: data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
      duration: '10:30', // Приблизительная продолжительность
      channel: data.author_name || 'YouTube канал',
      views: '1.2M', // Примерные просмотры
      uploadTime: '1 день назад',
      description: data.title,
      videoUrl: `https://www.youtube.com/embed/${videoId}?autoplay=1&modestbranding=1&rel=0&showinfo=0`,
      createdAt: new Date()
    };
  } catch (error) {
    console.error('oEmbed error:', error);
    
    // Fallback - базовая информация
    return {
      id: 0,
      videoId: videoId,
      title: `Видео ${videoId}`,
      thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
      duration: '10:30',
      channel: 'YouTube канал',
      views: '1.2M',
      uploadTime: '1 день назад',
      description: `Описание видео ${videoId}`,
      videoUrl: `https://www.youtube.com/embed/${videoId}?autoplay=1&modestbranding=1&rel=0&showinfo=0`,
      createdAt: new Date()
    };
  }
}

async function getTrendingVideos() {
  try {
    // Имитируем загрузку популярных видео
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Возвращаем реальные YouTube видео
    const trendingVideos = [
      {
        videoId: 'dQw4w9WgXcQ',
        title: 'Rick Astley - Never Gonna Give You Up (Official Video)',
        thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
        duration: '3:33',
        channel: 'Rick Astley',
        views: '1.4B просмотров',
        uploadTime: '14 лет назад',
        description: 'The official video for "Never Gonna Give You Up" by Rick Astley',
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
      },
      {
        videoId: '9bZkp7q19f0',
        title: 'PSY - GANGNAM STYLE(강남스타일) M/V',
        thumbnail: 'https://img.youtube.com/vi/9bZkp7q19f0/maxresdefault.jpg',
        duration: '4:13',
        channel: 'officialpsy',
        views: '4.8B просмотров',
        uploadTime: '12 лет назад',
        description: 'PSY - GANGNAM STYLE(강남스타일) M/V @ https://youtu.be/9bZkp7q19f0',
        videoUrl: 'https://www.youtube.com/watch?v=9bZkp7q19f0'
      },
      {
        videoId: 'kJQP7kiw5Fk',
        title: 'Luis Fonsi - Despacito ft. Daddy Yankee',
        thumbnail: 'https://img.youtube.com/vi/kJQP7kiw5Fk/maxresdefault.jpg',
        duration: '4:42',
        channel: 'LuisFonsiVEVO',
        views: '8.1B просмотров',
        uploadTime: '7 лет назад',
        description: '"Despacito" available at: iTunes: http://smarturl.it/DespacitoiTunes',
        videoUrl: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk'
      },
      {
        videoId: 'fJ9rUzIMcZQ',
        title: 'Queen – Bohemian Rhapsody (Official Video Remastered)',
        thumbnail: 'https://img.youtube.com/vi/fJ9rUzIMcZQ/maxresdefault.jpg',
        duration: '5:55',
        channel: 'Queen Official',
        views: '1.8B просмотров',
        uploadTime: '13 лет назад',
        description: 'Taken from A Night At The Opera, 1975.',
        videoUrl: 'https://www.youtube.com/watch?v=fJ9rUzIMcZQ'
      },
      {
        videoId: 'YQHsXMglC9A',
        title: 'Adele - Hello (Official Music Video)',
        thumbnail: 'https://img.youtube.com/vi/YQHsXMglC9A/maxresdefault.jpg',
        duration: '6:07',
        channel: 'Adele',
        views: '3.2B просмотров',
        uploadTime: '8 лет назад',
        description: 'Adele\'s official music video for "Hello"',
        videoUrl: 'https://www.youtube.com/watch?v=YQHsXMglC9A'
      },
      {
        videoId: 'hT_nvWreIhg',
        title: 'The Weeknd - Blinding Lights (Official Video)',
        thumbnail: 'https://img.youtube.com/vi/hT_nvWreIhg/maxresdefault.jpg',
        duration: '4:21',
        channel: 'The Weeknd',
        views: '1.1B просмотров',
        uploadTime: '4 года назад',
        description: 'Official music video by The Weeknd performing "Blinding Lights"',
        videoUrl: 'https://www.youtube.com/watch?v=hT_nvWreIhg'
      },
      {
        videoId: 'JGwWNGJdvx8',
        title: 'Ed Sheeran - Shape of You (Official Video)',
        thumbnail: 'https://img.youtube.com/vi/JGwWNGJdvx8/maxresdefault.jpg',
        duration: '3:54',
        channel: 'Ed Sheeran',
        views: '5.8B просмотров',
        uploadTime: '7 лет назад',
        description: 'The official music video for Ed Sheeran - Shape of You',
        videoUrl: 'https://www.youtube.com/watch?v=JGwWNGJdvx8'
      },
      {
        videoId: 'v5',
        title: 'Спорт: Чемпионат мира по футболу 2025 - главные события',
        thumbnail: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg',
        duration: '21:18',
        channel: 'Спорт 24/7',
        views: '1.5M просмотров',
        uploadTime: '6 часов назад',
        description: 'Обзор самых захватывающих моментов чемпионата мира, интервью с игроками и прогнозы экспертов.',
        videoUrl: null
      }
    ];
    
    return trendingVideos;
  } catch (error) {
    console.error('Ошибка загрузки популярных видео:', error);
    return [];
  }
}

// Utility functions
function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      return match[1];
    }
  }
  
  return null;
}

function formatDuration(seconds: number): string {
  if (!seconds) return '0:00';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

function formatViews(views: number | string): string {
  if (!views) return '0';
  
  const num = typeof views === 'string' ? parseInt(views.replace(/[^\d]/g, '')) : views;
  
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  } else if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`;
  }
  
  return num.toString();
}

function formatUploadDate(uploadDate: string): string {
  if (!uploadDate) return 'Неизвестно';
  
  try {
    const date = new Date(uploadDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
      return '1 день назад';
    } else if (diffDays < 7) {
      return `${diffDays} дней назад`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} ${weeks === 1 ? 'неделя' : 'недели'} назад`;
    } else if (diffDays < 365) {
      const months = Math.floor(diffDays / 30);
      return `${months} ${months === 1 ? 'месяц' : 'месяцев'} назад`;
    } else {
      const years = Math.floor(diffDays / 365);
      return `${years} ${years === 1 ? 'год' : 'лет'} назад`;
    }
  } catch (error) {
    return 'Неизвестно';
  }
}
