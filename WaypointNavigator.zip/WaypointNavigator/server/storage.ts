import { videos, searchResults, type Video, type InsertVideo, type SearchResult, type InsertSearchResult } from "@shared/schema";

export interface IStorage {
  // Video operations
  getVideo(videoId: string): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  searchVideos(query: string): Promise<Video[]>;
  
  // Search history operations
  saveSearchResult(searchResult: InsertSearchResult): Promise<SearchResult>;
  getSearchHistory(limit?: number): Promise<SearchResult[]>;
}

export class MemStorage implements IStorage {
  private videos: Map<string, Video>;
  private searchResults: Map<number, SearchResult>;
  private currentVideoId: number;
  private currentSearchId: number;

  constructor() {
    this.videos = new Map();
    this.searchResults = new Map();
    this.currentVideoId = 1;
    this.currentSearchId = 1;
  }

  async getVideo(videoId: string): Promise<Video | undefined> {
    return Array.from(this.videos.values()).find(
      (video) => video.videoId === videoId
    );
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = this.currentVideoId++;
    const video: Video = { 
      id,
      videoId: insertVideo.videoId,
      title: insertVideo.title,
      description: insertVideo.description || null,
      thumbnail: insertVideo.thumbnail,
      duration: insertVideo.duration,
      channel: insertVideo.channel,
      views: insertVideo.views || null,
      uploadTime: insertVideo.uploadTime || null,
      videoUrl: insertVideo.videoUrl || null,
      createdAt: new Date()
    };
    this.videos.set(video.videoId, video);
    return video;
  }

  async searchVideos(query: string): Promise<Video[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.videos.values()).filter(
      (video) => 
        video.title.toLowerCase().includes(lowerQuery) ||
        video.channel.toLowerCase().includes(lowerQuery) ||
        (video.description && video.description.toLowerCase().includes(lowerQuery))
    );
  }

  async saveSearchResult(insertSearchResult: InsertSearchResult): Promise<SearchResult> {
    const id = this.currentSearchId++;
    const searchResult: SearchResult = {
      ...insertSearchResult,
      id,
      createdAt: new Date()
    };
    this.searchResults.set(id, searchResult);
    return searchResult;
  }

  async getSearchHistory(limit: number = 50): Promise<SearchResult[]> {
    return Array.from(this.searchResults.values())
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
