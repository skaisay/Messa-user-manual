import { Clock, ThumbsUp, PlaySquare, ArrowDown, History, Film } from 'lucide-react';
import { VideoCard } from '../components/VideoCard';
import { mockVideos, mockPlaylists } from '../data/mockData';

export const Library = ({ onVideoClick }) => {
  return (
    <div className="pb-4">
      {/* History section */}
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-lg">History</h2>
          <button className="text-blue-600 text-sm font-medium">View all</button>
        </div>
        
        <div className="flex overflow-x-auto space-x-3 scrollbar-hide pb-2">
          {mockVideos.slice(0, 4).map((video) => (
            <div key={video.id} className="w-40 flex-shrink-0" onClick={() => onVideoClick(video)}>
              <div className="relative pb-[56.25%] bg-gray-200 rounded-xl overflow-hidden">
                <img 
                  src={video.thumbnail} 
                  alt={video.title}
                  className="absolute top-0 left-0 w-full h-full object-cover"
                />
                <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
                  {video.duration}
                </div>
              </div>
              
              <h3 className="font-medium text-xs mt-1 line-clamp-2">
                {video.title}
              </h3>
              
              <p className="text-gray-600 text-xs mt-0.5">
                {video.channelName}
              </p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Playlists section */}
      <div className="px-4 py-3 border-t">
        <h2 className="font-bold text-lg mb-3">Playlists</h2>
        
        {mockPlaylists.map((playlist) => (
          <div key={playlist.id} className="flex items-center py-2">
            <div className="relative w-20 h-20 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
              <img 
                src={playlist.thumbnail} 
                alt={playlist.title}
                className="absolute top-0 left-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                <span className="text-white font-bold">{playlist.videoCount}</span>
              </div>
            </div>
            
            <div className="ml-3 flex-1">
              <h3 className="font-medium text-sm">
                {playlist.title}
              </h3>
              <p className="text-gray-600 text-xs">
                {playlist.channelName} • {playlist.videoCount} videos
              </p>
              <p className="text-gray-600 text-xs mt-1">
                Updated {playlist.lastUpdated}
              </p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Your videos section */}
      <div className="px-4 py-3 border-t">
        <h2 className="font-bold text-lg mb-3">Your videos</h2>
        <VideoCard video={mockVideos[0]} onVideoClick={onVideoClick} />
      </div>
      
      {/* Quick links */}
      <div className="px-4 py-3 border-t">
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center py-3">
            <History size={20} className="text-gray-600 mr-3" />
            <span className="text-sm">History</span>
          </button>
          
          <button className="flex items-center py-3">
            <Film size={20} className="text-gray-600 mr-3" />
            <span className="text-sm">Your videos</span>
          </button>
          
          <button className="flex items-center py-3">
            <ArrowDown size={20} className="text-gray-600 mr-3" />
            <span className="text-sm">Downloads</span>
          </button>
          
          <button className="flex items-center py-3">
            <PlaySquare size={20} className="text-gray-600 mr-3" />
            <span className="text-sm">Your clips</span>
          </button>
          
          <button className="flex items-center py-3">
            <Clock size={20} className="text-gray-600 mr-3" />
            <span className="text-sm">Watch later</span>
          </button>
          
          <button className="flex items-center py-3">
            <ThumbsUp size={20} className="text-gray-600 mr-3" />
            <span className="text-sm">Liked videos</span>
          </button>
        </div>
      </div>
    </div>
  );
};