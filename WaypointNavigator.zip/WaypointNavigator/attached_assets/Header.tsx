import { Search, Mic, BellRing, User } from 'lucide-react';
import { useState } from 'react';
import { Logo } from './Logo';

export const Header = () => {
  const [isSearchActive, setIsSearchActive] = useState(false);

  return (
    <header className="sticky top-0 z-10 bg-white shadow-sm">
      {!isSearchActive ? (
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center">
            <Logo />
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              className="p-2 rounded-full hover:bg-gray-100"
              onClick={() => setIsSearchActive(true)}
            >
              <Search size={22} />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-100">
              <Mic size={22} />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-100">
              <BellRing size={22} />
            </button>
            <button className="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center">
              <User size={18} />
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center h-14 px-2">
          <button 
            className="p-2 rounded-full hover:bg-gray-100 mr-2"
            onClick={() => setIsSearchActive(false)}
          >
            <span className="text-xl font-bold">←</span>
          </button>
          <div className="flex-1 flex items-center bg-gray-100 rounded-full px-4 h-10">
            <Search size={18} className="text-gray-500 mr-2" />
            <input 
              type="text" 
              placeholder="Search YouTube" 
              className="flex-1 bg-transparent border-none outline-none" 
              autoFocus
            />
          </div>
          <button className="p-2 ml-2 rounded-full hover:bg-gray-100">
            <Mic size={22} />
          </button>
        </div>
      )}

      <div className="flex items-center overflow-x-auto scrollbar-hide px-4 py-2 space-x-3 border-b">
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">All</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">Music</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">Gaming</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">Podcasts</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">Live</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">News</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">Sports</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">React</button>
        <button className="whitespace-nowrap bg-gray-100 rounded-lg text-sm px-3 py-1.5 font-medium">JavaScript</button>
      </div>
    </header>
  );
};