import { ArrowLeft, ThumbsUp, ThumbsDown, Share, Download, Plus, MoreVertical } from 'lucide-react';
import { useState } from 'react';

export const VideoPlayer = ({ video, onClose }) => {
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  
  return (
    <div className="fixed inset-0 bg-white z-20 flex flex-col">
      <div className="relative h-56 bg-black">
        <button 
          className="absolute top-3 left-3 z-10 w-8 h-8 flex items-center justify-center bg-black bg-opacity-50 rounded-full"
          onClick={onClose}
        >
          <ArrowLeft size={18} className="text-white" />
        </button>
        
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="w-full h-full object-cover"
        />
        
        <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-black to-transparent"></div>
      </div>
      
      <div className="px-4 py-3 border-b">
        <h1 className="font-bold text-lg">{video.title}</h1>
        
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-full bg-gray-300 overflow-hidden">
              <img 
                src={video.channelImage} 
                alt={video.channelName}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="ml-2">
              <p className="text-sm font-medium">{video.channelName}</p>
              <p className="text-xs text-gray-600">{video.subscribers} subscribers</p>
            </div>
          </div>
          
          <button className="bg-black text-white text-sm font-medium px-4 py-1.5 rounded-full">
            Subscribe
          </button>
        </div>
        
        <div className="flex items-center justify-between mt-3 overflow-x-auto scrollbar-hide">
          <div className="flex items-center rounded-full bg-gray-100 mr-2">
            <button className="flex items-center space-x-1 px-3 py-1.5 border-r border-gray-300">
              <ThumbsUp size={18} />
              <span className="text-sm">{video.likes}</span>
            </button>
            <button className="px-3 py-1.5">
              <ThumbsDown size={18} />
            </button>
          </div>
          
          <button className="flex items-center space-x-1 bg-gray-100 rounded-full px-3 py-1.5 mr-2">
            <Share size={18} />
            <span className="text-sm whitespace-nowrap">Share</span>
          </button>
          
          <button className="flex items-center space-x-1 bg-gray-100 rounded-full px-3 py-1.5 mr-2">
            <Download size={18} />
            <span className="text-sm whitespace-nowrap">Download</span>
          </button>
          
          <button className="flex items-center space-x-1 bg-gray-100 rounded-full px-3 py-1.5 mr-2">
            <Plus size={18} />
            <span className="text-sm whitespace-nowrap">Save</span>
          </button>
          
          <button className="p-2 rounded-full bg-gray-100">
            <MoreVertical size={18} />
          </button>
        </div>
      </div>
      
      <div 
        className={`px-4 py-3 border-b ${!isDescriptionExpanded ? 'max-h-20 overflow-hidden' : ''}`}
        onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
      >
        <div className="text-sm">
          <p className="text-gray-700 font-medium">
            {video.views} views • {video.uploadTime}
          </p>
          <p className="mt-2 whitespace-pre-line">
            {video.description}
          </p>
        </div>
        {!isDescriptionExpanded && (
          <div className="absolute bottom-0 left-0 right-0 h-10 bg-gradient-to-t from-white to-transparent"></div>
        )}
      </div>
      
      <div className="px-4 py-3 flex-1 overflow-y-auto">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold">Comments • 1.5K</h3>
          <button>
            <MoreVertical size={18} />
          </button>
        </div>
        
        <div className="flex items-start mb-6">
          <div className="h-8 w-8 rounded-full bg-gray-300 flex-shrink-0 overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg"
              alt="User"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="ml-3 flex-1">
            <div className="flex items-center">
              <p className="text-sm font-medium">User123</p>
              <p className="text-xs text-gray-600 ml-2">2 days ago</p>
            </div>
            <p className="text-sm mt-1">
              This video was super helpful! Thanks for sharing your knowledge.
            </p>
            <div className="flex items-center mt-1 text-gray-600">
              <button className="flex items-center mr-4">
                <ThumbsUp size={14} />
                <span className="text-xs ml-1">42</span>
              </button>
              <button>
                <ThumbsDown size={14} />
              </button>
            </div>
          </div>
        </div>
        
        {/* More comments would go here */}
      </div>
    </div>
  );
};