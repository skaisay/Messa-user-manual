export const ShortCard = ({ short }) => {
  return (
    <div className="flex-shrink-0 w-[150px] mr-2">
      <div className="relative pb-[177.78%] bg-gray-200 rounded-xl overflow-hidden">
        <img 
          src={short.thumbnail} 
          alt={short.title}
          className="absolute top-0 left-0 w-full h-full object-cover"
        />
      </div>
      
      <h3 className="font-medium text-sm mt-2 line-clamp-2">
        {short.title}
      </h3>
      
      <p className="text-gray-600 text-xs mt-1">
        {short.views} views
      </p>
    </div>
  );
};