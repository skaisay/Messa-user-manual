import { VideoCard } from '../components/VideoCard';
import { ChannelItem } from '../components/ChannelItem';
import { mockVideos, mockChannels } from '../data/mockData';

export const Subscriptions = ({ onVideoClick }) => {
  return (
    <div className="pb-4">
      {/* Channels section */}
      <div className="px-4 py-3">
        <h2 className="font-bold text-lg mb-3">Channels</h2>
        
        <div className="flex overflow-x-auto space-x-4 py-2 scrollbar-hide">
          {mockChannels.map((channel) => (
            <div key={channel.id} className="flex flex-col items-center flex-shrink-0">
              <div className="w-16 h-16 rounded-full bg-gray-300 overflow-hidden">
                <img 
                  src={channel.image} 
                  alt={channel.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-xs mt-1 text-center w-20 truncate">{channel.name}</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* All subscriptions */}
      <div className="px-4 py-3 border-t">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-lg">All subscriptions</h2>
          <select className="text-sm border-none bg-transparent">
            <option>Recently uploaded</option>
            <option>A-Z</option>
          </select>
        </div>
        
        {mockChannels.map((channel) => (
          <ChannelItem key={channel.id} channel={channel} />
        ))}
      </div>
      
      {/* Recent videos from subscriptions */}
      <div className="px-4 py-3 border-t">
        <h2 className="font-bold text-lg mb-3">Recent videos</h2>
        
        {mockVideos.slice(0, 4).map((video) => (
          <VideoCard key={video.id} video={video} onVideoClick={onVideoClick} />
        ))}
      </div>
    </div>
  );
};