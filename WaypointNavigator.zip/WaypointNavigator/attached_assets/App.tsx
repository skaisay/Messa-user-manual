import { useState } from 'react';
import { Home } from './pages/Home';
import { Shorts } from './pages/Shorts';
import { Subscriptions } from './pages/Subscriptions';
import { Library } from './pages/Library';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { VideoPlayer } from './components/VideoPlayer';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const [currentVideo, setCurrentVideo] = useState(null);

  const handleVideoClick = (video) => {
    setCurrentVideo(video);
    setIsPlayerOpen(true);
  };

  const handleClosePlayer = () => {
    setIsPlayerOpen(false);
  };

  return (
    <div className="h-screen flex flex-col bg-white text-black">
      {!isPlayerOpen && (
        <>
          <Header />
          <main className="flex-1 overflow-y-auto pb-14">
            {activeTab === 'home' && <Home onVideoClick={handleVideoClick} />}
            {activeTab === 'shorts' && <Shorts />}
            {activeTab === 'subscriptions' && <Subscriptions onVideoClick={handleVideoClick} />}
            {activeTab === 'library' && <Library onVideoClick={handleVideoClick} />}
          </main>
          <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        </>
      )}
      
      {isPlayerOpen && currentVideo && (
        <VideoPlayer video={currentVideo} onClose={handleClosePlayer} />
      )}
    </div>
  );
}

export default App;