import { Home as HomeIcon, Play, Plus, Users, Library } from 'lucide-react';

export const Navigation = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home', icon: HomeIcon, label: 'Home' },
    { id: 'shorts', icon: Play, label: 'Shorts' },
    { id: 'create', icon: Plus, label: '' },
    { id: 'subscriptions', icon: Users, label: 'Subscriptions' },
    { id: 'library', icon: Library, label: 'Library' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t h-14 flex items-center z-10">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className={`flex-1 flex flex-col items-center justify-center h-full ${
            activeTab === tab.id ? 'text-black' : 'text-gray-600'
          }`}
          onClick={() => tab.id !== 'create' && onTabChange(tab.id)}
        >
          {tab.id === 'create' ? (
            <div className="flex items-center justify-center w-10 h-10 bg-gray-100 rounded-full">
              <tab.icon size={22} />
            </div>
          ) : (
            <>
              <tab.icon size={22} />
              <span className="text-xs mt-1">{tab.label}</span>
            </>
          )}
        </button>
      ))}
    </nav>
  );
};