export const VideoCard = ({ video, onVideoClick }) => {
  return (
    <div className="mb-4" onClick={() => onVideoClick(video)}>
      <div className="relative pb-[56.25%] bg-gray-200 rounded-xl overflow-hidden">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="absolute top-0 left-0 w-full h-full object-cover"
        />
        <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
          {video.duration}
        </div>
      </div>
      
      <div className="flex mt-2 px-2">
        <div className="h-9 w-9 rounded-full bg-gray-300 flex-shrink-0 overflow-hidden">
          <img 
            src={video.channelImage} 
            alt={video.channelName}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="ml-3 flex-1">
          <h3 className="font-medium text-sm line-clamp-2">
            {video.title}
          </h3>
          <p className="text-gray-600 text-xs mt-1">
            {video.channelName}
          </p>
          <p className="text-gray-600 text-xs">
            {video.views} • {video.uploadTime}
          </p>
        </div>
      </div>
    </div>
  );
};