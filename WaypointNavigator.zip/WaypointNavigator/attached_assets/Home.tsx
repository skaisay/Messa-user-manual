import { VideoCard } from '../components/VideoCard';
import { ShortCard } from '../components/ShortCard';
import { mockVideos, mockShorts } from '../data/mockData';

export const Home = ({ onVideoClick }) => {
  return (
    <div className="pb-4">
      {/* Videos section */}
      <div className="px-4">
        {mockVideos.slice(0, 3).map((video) => (
          <VideoCard key={video.id} video={video} onVideoClick={onVideoClick} />
        ))}
      </div>
      
      {/* Shorts section */}
      <div className="py-4 border-t border-b">
        <div className="flex items-center px-4 mb-3">
          <div className="text-red-600 font-bold text-lg mr-1">⏱</div>
          <h2 className="font-bold text-lg">Shorts</h2>
        </div>
        
        <div className="flex overflow-x-auto px-4 scrollbar-hide">
          {mockShorts.map((short) => (
            <ShortCard key={short.id} short={short} />
          ))}
        </div>
      </div>
      
      {/* More videos */}
      <div className="px-4 mt-4">
        {mockVideos.slice(3).map((video) => (
          <VideoCard key={video.id} video={video} onVideoClick={onVideoClick} />
        ))}
      </div>
    </div>
  );
};