export const mockVideos = [
  {
    id: 'v1',
    title: 'How to Build a Modern React Application with TypeScript and Tailwind CSS',
    thumbnail: 'https://images.pexels.com/photos/4974915/pexels-photo-4974915.jpeg',
    channelName: 'CodeMaster',
    channelImage: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    views: '1.2M views',
    uploadTime: '2 weeks ago',
    duration: '15:42',
    likes: '45K',
    subscribers: '1.2M',
    description: 'In this comprehensive tutorial, I walk you through building a modern React application using TypeScript and Tailwind CSS. You\'ll learn best practices, performance optimization techniques, and how to structure your project for scalability.\n\nTimestamps:\n00:00 Introduction\n02:15 Setting up the project\n08:30 Implementing components\n15:20 Styling with Tailwind\n23:45 TypeScript tips and tricks\n30:10 Conclusion'
  },
  {
    id: 'v2',
    title: 'Learn Piano in 30 Days - Day 1: Basics and First Song',
    thumbnail: 'https://images.pexels.com/photos/164743/pexels-photo-164743.jpeg',
    channelName: 'MusicMentor',
    channelImage: 'https://images.pexels.com/photos/1270076/pexels-photo-1270076.jpeg',
    views: '3.5M views',
    uploadTime: '1 month ago',
    duration: '22:18',
    likes: '120K',
    subscribers: '2.8M',
    description: 'Day 1 of our 30-day piano learning journey! Today we cover the absolute basics - hand positioning, identifying notes, and playing your very first song. No prior experience needed!\n\nGet the free sheet music: https://example.com/piano-sheets'
  },
  {
    id: 'v3',
    title: 'NYC Morning Routine 2025 | Productive Day in the Life',
    thumbnail: 'https://images.pexels.com/photos/2224861/pexels-photo-2224861.png',
    channelName: 'Urban Lifestyle',
    channelImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    views: '890K views',
    uploadTime: '3 days ago',
    duration: '18:05',
    likes: '62K',
    subscribers: '950K',
    description: 'Join me for a productive morning in New York City! I show you my complete routine from 5AM wake-up to heading to the office, including my skincare routine, workout, breakfast recipe, and commute tips.'
  },
  {
    id: 'v4',
    title: 'I Tried the Viral TikTok Pasta Recipe and This Happened...',
    thumbnail: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg',
    channelName: 'Food Adventures',
    channelImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    views: '4.2M views',
    uploadTime: '1 week ago',
    duration: '12:37',
    likes: '387K',
    subscribers: '3.4M',
    description: 'Today I\'m testing the viral feta pasta that\'s all over TikTok! Is it worth the hype? Watch to find out my honest review, some tips to make it even better, and my ultimate verdict!'
  },
  {
    id: 'v5',
    title: 'Top 10 Hidden Gems in Japan You Need to Visit in 2025',
    thumbnail: 'https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg',
    channelName: 'Travel Insider',
    channelImage: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
    views: '720K views',
    uploadTime: '5 days ago',
    duration: '25:14',
    likes: '98K',
    subscribers: '1.7M',
    description: 'Looking to explore Japan beyond Tokyo and Kyoto? In this video, I share 10 incredible destinations most tourists never visit. From secret onsens to hidden mountain villages, these spots will give you an authentic Japanese experience away from the crowds.'
  },
  {
    id: 'v6',
    title: 'How I Built a 7-Figure Business in 2 Years (No Loans or Investors)',
    thumbnail: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg',
    channelName: 'Entrepreneur Daily',
    channelImage: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
    views: '1.8M views',
    uploadTime: '2 months ago',
    duration: '32:49',
    likes: '215K',
    subscribers: '2.2M',
    description: 'In this video, I break down exactly how I built my business from zero to seven figures in just 24 months with no outside funding. I cover mindset shifts, practical strategies, and the biggest mistakes to avoid.'
  },
  {
    id: 'v7',
    title: '10-Minute Full Body Workout (No Equipment Needed)',
    thumbnail: 'https://images.pexels.com/photos/2294361/pexels-photo-2294361.jpeg',
    channelName: 'Fitness Focus',
    channelImage: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
    views: '5.1M views',
    uploadTime: '3 months ago',
    duration: '10:00',
    likes: '432K',
    subscribers: '4.5M',
    description: 'This quick but effective 10-minute workout targets every major muscle group with no equipment required. Perfect for busy days or when traveling! Follow along and get your heart rate up with these simple but powerful exercises.'
  }
];

export const mockShorts = [
  {
    id: 's1',
    title: 'This dog can solve math problems 🤯',
    thumbnail: 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg',
    views: '4.8M'
  },
  {
    id: 's2',
    title: 'Easy 5-minute dinner hack',
    thumbnail: 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg',
    views: '2.1M'
  },
  {
    id: 's3',
    title: 'You\'ve been tying your shoes wrong',
    thumbnail: 'https://images.pexels.com/photos/1159670/pexels-photo-1159670.jpeg',
    views: '8.3M'
  },
  {
    id: 's4',
    title: 'How to make perfect coffee at home',
    thumbnail: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    views: '1.7M'
  },
  {
    id: 's5',
    title: 'This trick will improve your memory',
    thumbnail: 'https://images.pexels.com/photos/256431/pexels-photo-256431.jpeg',
    views: '3.5M'
  },
  {
    id: 's6',
    title: 'New iPhone hack you didn\'t know about',
    thumbnail: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg',
    views: '5.2M'
  }
];

export const mockChannels = [
  {
    id: 'c1',
    name: 'CodeMaster',
    image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    subscribers: '1.2M'
  },
  {
    id: 'c2',
    name: 'MusicMentor',
    image: 'https://images.pexels.com/photos/1270076/pexels-photo-1270076.jpeg',
    subscribers: '2.8M'
  },
  {
    id: 'c3',
    name: 'Urban Lifestyle',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    subscribers: '950K'
  },
  {
    id: 'c4',
    name: 'Food Adventures',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    subscribers: '3.4M'
  },
  {
    id: 'c5',
    name: 'Travel Insider',
    image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
    subscribers: '1.7M'
  },
  {
    id: 'c6',
    name: 'Entrepreneur Daily',
    image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
    subscribers: '2.2M'
  },
  {
    id: 'c7',
    name: 'Fitness Focus',
    image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
    subscribers: '4.5M'
  }
];

export const mockPlaylists = [
  {
    id: 'p1',
    title: 'Favorite Coding Tutorials',
    thumbnail: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg',
    channelName: 'My Channel',
    videoCount: 14,
    lastUpdated: '2 days ago'
  },
  {
    id: 'p2',
    title: 'Workout Routines',
    thumbnail: 'https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg',
    channelName: 'My Channel',
    videoCount: 8,
    lastUpdated: '1 week ago'
  },
  {
    id: 'p3',
    title: 'Music for Studying',
    thumbnail: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    channelName: 'My Channel',
    videoCount: 23,
    lastUpdated: '3 days ago'
  }
];