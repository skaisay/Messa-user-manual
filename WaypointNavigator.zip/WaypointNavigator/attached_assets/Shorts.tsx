export const Shorts = () => {
  const shortsData = [
    {
      id: 's1',
      thumbnail: 'https://images.pexels.com/photos/3075993/pexels-photo-3075993.jpeg',
      title: 'Amazing sunset timelapse',
      creator: 'Nature Channel',
      likes: '1.2M',
      comments: '3.4K'
    },
    {
      id: 's2',
      thumbnail: 'https://images.pexels.com/photos/2792157/pexels-photo-2792157.jpeg',
      title: 'Pro skateboarding trick tutorial',
      creator: 'Skate Pro',
      likes: '543K',
      comments: '1.2K'
    },
    {
      id: 's3',
      thumbnail: 'https://images.pexels.com/photos/3814639/pexels-photo-3814639.jpeg',
      title: 'How to make perfect pancakes',
      creator: 'Food Master',
      likes: '892K',
      comments: '2.1K'
    }
  ];

  return (
    <div className="h-full">
      {/* Short currently playing */}
      <div className="relative h-full bg-black">
        <img 
          src={shortsData[0].thumbnail}
          alt={shortsData[0].title}
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        {/* Right side actions */}
        <div className="absolute right-4 bottom-20 flex flex-col items-center space-y-5">
          <button className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
              <span className="text-white text-xl">👍</span>
            </div>
            <span className="text-white text-xs mt-1">{shortsData[0].likes}</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
              <span className="text-white text-xl">👎</span>
            </div>
            <span className="text-white text-xs mt-1">Dislike</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
              <span className="text-white text-xl">💬</span>
            </div>
            <span className="text-white text-xs mt-1">{shortsData[0].comments}</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
              <span className="text-white text-xl">↗️</span>
            </div>
            <span className="text-white text-xs mt-1">Share</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center rotate-90">
              <span className="text-white text-xl">⋯</span>
            </div>
          </button>
        </div>
        
        {/* Bottom content info */}
        <div className="absolute left-4 right-14 bottom-4">
          <h3 className="text-white font-medium text-sm">
            {shortsData[0].title}
          </h3>
          <p className="text-white text-xs mt-1">
            {shortsData[0].creator}
          </p>
          <button className="mt-2 bg-red-600 text-white text-xs font-medium px-4 py-1.5 rounded-full">
            Subscribe
          </button>
        </div>
      </div>
    </div>
  );
};