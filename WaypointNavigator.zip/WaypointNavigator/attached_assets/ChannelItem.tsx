export const ChannelItem = ({ channel }) => {
  return (
    <div className="flex items-center py-2">
      <div className="h-10 w-10 rounded-full bg-gray-300 flex-shrink-0 overflow-hidden">
        <img 
          src={channel.image} 
          alt={channel.name}
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="ml-3 flex-1">
        <h3 className="font-medium text-sm">
          {channel.name}
        </h3>
        <p className="text-gray-600 text-xs">
          {channel.subscribers} subscribers
        </p>
      </div>
      
      <button className="bg-black text-white text-sm font-medium px-4 py-1.5 rounded-full">
        Subscribe
      </button>
    </div>
  );
};